DolbyAtmos
version=v3.5.1.28
versionCode=28
description=ported  for any Android 9-14

## Tested on
- Android 10 CrDroid ROM
- Android 11 DotOS ROM
- Android 12 AncientOS ROM
- Android 13 CrDroid ROM & AlphaDroid ROM
- Android 14 LineageOS ROM
 
## Sources
- https://dumps.tadiphone.dev/dumps/razer/bolt bolt-user-9-P-SMR1-RC008-ATT-190626-3239-release-keys
- libswvqe.so: LENOVO TB-J606F
- system_support: CrDroid ROM Android 13
- libmagiskpolicy.so: Kitsune Mask R65C33E4F
